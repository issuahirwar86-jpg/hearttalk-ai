import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../../services/hearttalk_api.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _api = HeartTalkApiClient();
  final List<Map<String, String>> _messages = [];
  final String _selectedModel = 'gemini-3.1-flash-lite';
  final String _language = 'en';
  bool _webSearch = false;
  bool _streaming = false;

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _streaming) return;
    _controller.clear();
    setState(() {
      _messages.add({'role': 'user', 'content': text});
      _messages.add({'role': 'assistant', 'content': ''});
      _streaming = true;
    });

    try {
      await for (final delta in _api.streamChat(
        modelId: _selectedModel,
        message: text,
        language: _language,
        useWebSearch: _webSearch,
      )) {
        setState(() {
          _messages.last['content'] = (_messages.last['content'] ?? '') + delta;
        });
      }
    } catch (err) {
      setState(() {
        _messages.last['content'] = 'Error: $err';
      });
    } finally {
      setState(() => _streaming = false);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HeartTalk AI'),
        actions: [
          IconButton(
            icon: Icon(_webSearch ? Icons.public : Icons.public_off),
            onPressed: () => setState(() => _webSearch = !_webSearch),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final isUser = msg['role'] == 'user';
                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: MarkdownBody(data: msg['content'] ?? ''),
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(
                        hintText: 'Ask HeartTalk AI (English, Hindi, Hinglish)...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: _streaming ? null : _send,
                    child: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
