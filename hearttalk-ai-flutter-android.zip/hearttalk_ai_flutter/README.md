# HeartTalk AI — Flutter Android Client

## 1. Firebase Setup
- Firebase Project ID: `steadfast-transmitter-qg33w`
- Named Firestore Database ID: `ai-studio-0e3707ae-4557-48df-a5a7-d3ae7d01a008`

Run inside `flutter_app/`:
```bash
dart pub global activate flutterfire_cli
flutterfire configure --project=steadfast-transmitter-qg33w --platforms=android --android-package-name=com.hearttalk.ai
```
Update `lib/main.dart` to pass `options: DefaultFirebaseOptions.currentPlatform`.

Add Android SHA-1 and SHA-256 certificates (`cd android && ./gradlew signingReport`) in Firebase Console for Google Sign-In.

## 2. Build Release APK (No API Keys in APK)
```bash
flutter pub get
flutter build apk --release --dart-define=API_BASE_URL=https://ais-pre-df2flsftpiv5aai2ewqdy3-817611524917.asia-northeast1.run.app
```
For local emulator testing against the root Express server on port `3000`:
```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000
```
